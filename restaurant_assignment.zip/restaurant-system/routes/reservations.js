const express = require('express');
const router = express.Router();
const Reservation = require('../models/Reservation');
const Table = require('../models/Table');
const { verifyToken, isAdmin } = require('../middleware/auth');

router.post('/', verifyToken, async (req, res) => {
  try {
    const { tableNumber, date, timeSlot, guests } = req.body;
    let table = await Table.findOne({ number: tableNumber });
    if (!table) {
      table = new Table({ number: tableNumber, capacity: tableNumber % 2 === 0 ? 4 : 2 });
      await table.save();
    }
    if (table.capacity < guests) {
      return res.status(400).json({ error: `Table capacity mismatch. Max guests allowed: ${table.capacity}.` });
    }
    const conflict = await Reservation.findOne({ table: table._id, date, timeSlot });
    if (conflict) return res.status(400).json({ error: "Table is already reserved for this slot" });
    const newRes = new Reservation({ user: req.user.id, table: table._id, date, timeSlot, guests });
    await newRes.save();
    res.status(201).json({ message: "Reservation confirmed successfully!", reservation: newRes });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.get('/my-bookings', verifyToken, async (req, res) => {
  try {
    const bookings = await Reservation.find({ user: req.user.id }).populate('table');
    res.json(bookings);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.get('/all', verifyToken, isAdmin, async (req, res) => {
  try {
    const query = {};
    if (req.query.date) query.date = req.query.date;
    const allBookings = await Reservation.find(query).populate('user', 'username').populate('table');
    res.json(allBookings);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.delete('/:id', verifyToken, async (req, res) => {
  try {
    const reservation = await Reservation.findById(req.params.id);
    if (!reservation) return res.status(404).json({ error: "Reservation not found" });
    if (reservation.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ error: "Unauthorized operation clearance" });
    }
    await Reservation.findByIdAndDelete(req.params.id);
    res.json({ message: "Reservation cancelled successfully" });
  } catch (err) { res.status(500).json({ error: err.message }); }
});
module.exports = router;
