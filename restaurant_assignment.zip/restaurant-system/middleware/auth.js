const jwt = require('jsonwebtoken');
exports.verifyToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.status(401).json({ error: "Access Denied: Missing Token" });
  try {
    const verified = jwt.verify(token, process.env.JWT_SECRET || 'secretkey123');
    req.user = verified;
    next();
  } catch (err) { res.status(403).json({ error: "Invalid Security Token" }); }
};
exports.isAdmin = (req, res, next) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: "Access Denied: Admin Clearance Required" });
  next();
};
