const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();
app.use(express.json());
app.use(cors());

app.use('/api/auth', require('./routes/auth'));
app.use('/api/reservations', require('./routes/reservations'));
app.use(express.static('public'));

const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/restaurantDB';
mongoose.connect(MONGO_URI)
  .then(() => console.log('Database Engine Synchronized'))
  .catch(err => console.log('Database sync offline/standby:', err.message));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`System Orchestrator live at port ${PORT}`));
